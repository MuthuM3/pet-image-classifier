import torch
from PIL import Image
from model import PetClassifier, predict_image

def load_model():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = PetClassifier().to(device)
    model.load_state_dict(torch.load('models/saved_models/pet_classifier.pth'))
    model.eval()
    return model

def predict(image_path):
    model = load_model()
    return predict_image(model, image_path)

if __name__ == '__main__':
    # Test prediction
    test_image = 'path/to/test/image.jpg'
    result = predict(test_image)
    print(f'Prediction: {result}')